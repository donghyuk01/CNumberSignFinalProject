﻿namespace 과제4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            share_id = new TextBox();
            label1 = new Label();
            add_button2 = new Button();
            button2 = new Button();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            panel3 = new Panel();
            textBox_t = new MaskedTextBox();
            add_button = new Button();
            dateTimePicker1 = new DateTimePicker();
            high = new RadioButton();
            save_button = new Button();
            middle = new RadioButton();
            load_button = new Button();
            edit_button = new Button();
            del_button = new Button();
            low = new RadioButton();
            button1 = new Button();
            panel1 = new Panel();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // share_id
            // 
            share_id.Location = new Point(39, 89);
            share_id.Name = "share_id";
            share_id.Size = new Size(229, 39);
            share_id.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(58, 43);
            label1.Name = "label1";
            label1.Size = new Size(189, 32);
            label1.TabIndex = 3;
            label1.Text = "공유하고싶은 ID";
            // 
            // add_button2
            // 
            add_button2.Location = new Point(307, 45);
            add_button2.Margin = new Padding(6);
            add_button2.Name = "add_button2";
            add_button2.Size = new Size(113, 83);
            add_button2.TabIndex = 5;
            add_button2.Text = "추가";
            add_button2.UseVisualStyleBackColor = true;
            add_button2.Click += add_button2_Click;
            // 
            // button2
            // 
            button2.Location = new Point(442, 43);
            button2.Margin = new Padding(6);
            button2.Name = "button2";
            button2.Size = new Size(113, 83);
            button2.TabIndex = 6;
            button2.Text = "삭제";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(button2);
            panel2.Controls.Add(add_button2);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(share_id);
            panel2.Location = new Point(0, 441);
            panel2.Name = "panel2";
            panel2.Size = new Size(1075, 483);
            panel2.TabIndex = 7;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(136, 29);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(797, 278);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox1);
            panel3.Location = new Point(0, 615);
            panel3.Name = "panel3";
            panel3.Size = new Size(1075, 309);
            panel3.TabIndex = 9;
            // 
            // textBox_t
            // 
            textBox_t.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox_t.Location = new Point(28, 74);
            textBox_t.Margin = new Padding(6);
            textBox_t.Name = "textBox_t";
            textBox_t.Size = new Size(602, 50);
            textBox_t.TabIndex = 0;
            // 
            // add_button
            // 
            add_button.Location = new Point(696, 163);
            add_button.Margin = new Padding(6);
            add_button.Name = "add_button";
            add_button.Size = new Size(329, 83);
            add_button.TabIndex = 1;
            add_button.Text = "추가";
            add_button.UseVisualStyleBackColor = true;
            add_button.Click += add_button_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(696, 87);
            dateTimePicker1.Margin = new Padding(6);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(327, 39);
            dateTimePicker1.TabIndex = 2;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // high
            // 
            high.AutoSize = true;
            high.Location = new Point(41, 183);
            high.Margin = new Padding(6);
            high.Name = "high";
            high.Size = new Size(93, 36);
            high.TabIndex = 3;
            high.TabStop = true;
            high.Text = "높음";
            high.UseVisualStyleBackColor = true;
            // 
            // save_button
            // 
            save_button.Location = new Point(709, 323);
            save_button.Margin = new Padding(6);
            save_button.Name = "save_button";
            save_button.Size = new Size(120, 92);
            save_button.TabIndex = 1;
            save_button.Text = "저장";
            save_button.UseVisualStyleBackColor = true;
            save_button.Click += save_button_Click;
            // 
            // middle
            // 
            middle.AutoSize = true;
            middle.Location = new Point(242, 183);
            middle.Margin = new Padding(6);
            middle.Name = "middle";
            middle.Size = new Size(93, 36);
            middle.TabIndex = 3;
            middle.TabStop = true;
            middle.Text = "중간";
            middle.UseVisualStyleBackColor = true;
            // 
            // load_button
            // 
            load_button.Location = new Point(857, 323);
            load_button.Margin = new Padding(6);
            load_button.Name = "load_button";
            load_button.Size = new Size(134, 92);
            load_button.TabIndex = 1;
            load_button.Text = "불러오기";
            load_button.UseVisualStyleBackColor = true;
            load_button.Click += load_button_Click;
            // 
            // edit_button
            // 
            edit_button.Location = new Point(242, 323);
            edit_button.Margin = new Padding(6);
            edit_button.Name = "edit_button";
            edit_button.Size = new Size(181, 92);
            edit_button.TabIndex = 1;
            edit_button.Text = "편집";
            edit_button.UseVisualStyleBackColor = true;
            edit_button.Click += edit_button_Click;
            // 
            // del_button
            // 
            del_button.Location = new Point(41, 323);
            del_button.Margin = new Padding(6);
            del_button.Name = "del_button";
            del_button.Size = new Size(181, 92);
            del_button.TabIndex = 1;
            del_button.Text = "삭제";
            del_button.UseVisualStyleBackColor = true;
            del_button.Click += del_button_Click;
            // 
            // low
            // 
            low.AutoSize = true;
            low.Location = new Point(444, 183);
            low.Margin = new Padding(6);
            low.Name = "low";
            low.Size = new Size(93, 36);
            low.TabIndex = 3;
            low.TabStop = true;
            low.Text = "낮음";
            low.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(911, 255);
            button1.Margin = new Padding(6);
            button1.Name = "button1";
            button1.Size = new Size(113, 49);
            button1.TabIndex = 4;
            button1.Text = "초기화";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(button1);
            panel1.Controls.Add(low);
            panel1.Controls.Add(del_button);
            panel1.Controls.Add(edit_button);
            panel1.Controls.Add(load_button);
            panel1.Controls.Add(middle);
            panel1.Controls.Add(save_button);
            panel1.Controls.Add(high);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(add_button);
            panel1.Controls.Add(textBox_t);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(6);
            panel1.Name = "panel1";
            panel1.Size = new Size(1075, 441);
            panel1.TabIndex = 0;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(14F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1075, 924);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Margin = new Padding(6);
            MinimumSize = new Size(1096, 665);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            Resize += Form2_Resize;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private TextBox share_id;
        private Label label1;
        private Button add_button2;
        private Button button2;
        private Panel panel2;
        public PictureBox pictureBox1;
        private Panel panel3;
        private MaskedTextBox textBox_t;
        private Button add_button;
        private DateTimePicker dateTimePicker1;
        private RadioButton high;
        private Button save_button;
        private RadioButton middle;
        private Button load_button;
        private Button edit_button;
        private Button del_button;
        private RadioButton low;
        private Button button1;
        private Panel panel1;
    }
}