﻿using Google.Protobuf;
using Microsoft.VisualBasic.ApplicationServices;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.PerformanceData;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 과제4
{
    public partial class Form3 : Form
    {
        private string good = "Y2l2aWw1OTQ5";
        Form1 f1;
        string connStr;
        public int isLogin_mode; //0: 로그인 1:회원가입
        public int unique; // 0: 중복이거나 확인 안 됨 1: 중복 없음(사용 가능)
        public Form3()
        {
            InitializeComponent();
            InitString();
            isLogin_mode = 0;
        }
        public Form3(Form1 f)
        {
            InitializeComponent();
            InitString();
            isLogin_mode = 0;
            f1 = f;
            this.ActiveControl = login;
            this.login.TextChanged += login_TextChanged;
        }
        private void InitString()
        {
            string p = Encoding.UTF8.GetString(Convert.FromBase64String(good));
            connStr = $"Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd={p}";
        }
        private void login_TextChanged(object sender, EventArgs e)
        {
            unique = 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string userId = login.Text.Trim();
            string userPwd = pwd.Text.Trim();

            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(userPwd))
            {
                MessageBox.Show("아이디와 비밀번호를 모두 입력해주세요.", "알림");
                return;
            }

            if (isLogin_mode == 0)
            {
                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();
                        string sql = "SELECT user_pwd, salt FROM `1101`.check_user WHERE user_id = @user_id";
                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@user_id", userId);

                            using (MySqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    string dbPwd = reader["user_pwd"].ToString();
                                    string salt = reader["salt"].ToString();
                                    string hashPwd = HashPwd(userPwd, salt);

                                    if (dbPwd == hashPwd)
                                    {
                                        MessageBox.Show("로그인 성공", "알림");
                                        f1.isLogin = 0;
                                        f1.set_id = userId;
                                        f1.Show();
                                        this.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("비밀번호가 일치하지 않습니다.", "로그인 실패");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("존재하지 않는 아이디입니다.", "로그인 실패");
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("로그인 처리 중 오류 발생:\n" + ex.Message, "오류");
                }
            }

            else if (isLogin_mode == 1)
            {

                if (unique == 0)
                {
                    MessageBox.Show("아이디 중복 확인을 먼저 진행해주세요.", "알림");
                    return;
                }

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();
                        string salt = GenerateSalt();
                        string hashPwd = HashPwd(userPwd, salt);

                        string sql = "INSERT INTO `1101`.`check_user`(user_id, user_pwd, salt) VALUES(@user_id, @user_pwd, @salt)";
                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@user_id", userId);
                            cmd.Parameters.AddWithValue("@user_pwd", hashPwd);
                            cmd.Parameters.AddWithValue("@salt", salt);

                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("성공적으로 등록되었습니다.", "알림");
                                Login_mode();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("회원가입 처리 중 오류 발생:\n" + ex.Message, "오류");
                }
            }

        }

        private string GenerateSalt()
        {
            byte[] b = new byte[32];
            using (var v = RandomNumberGenerator.Create())
            {
                v.GetBytes(b);
            }
            return Convert.ToBase64String(b);
        }
        private string HashPwd(string pwd, string salt)
        {
            using (SHA256 sha = SHA256.Create())
            {
                string saltPwd = pwd + salt;
                byte[] bytes = Encoding.UTF8.GetBytes(saltPwd);
                byte[] hashB = sha.ComputeHash(bytes);

                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashB)
                {
                    sb.Append(b.ToString("x2")); //x2 : 2글자 16진수
                }
                return sb.ToString();
            }
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login_mode();

        }
        private void Login_mode()
        {
            if (isLogin_mode == 0)
            {
                label1.Text = "회원가입";
                button1.Text = "회원가입";
                linkLabel1.Text = "로그인";
                button2.Visible = true;
                isLogin_mode = 1;
            }
            else if (isLogin_mode == 1)
            {
                label1.Text = "로그인";
                button1.Text = "로그인";
                linkLabel1.Text = "회원가입";
                button2.Visible = false;
                isLogin_mode = 0;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string userId = login.Text.Trim();

            if (string.IsNullOrEmpty(userId))
            {
                MessageBox.Show("중복 확인할 아이디를 입력해주세요.", "알림");
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    string sql = "SELECT user_id FROM `1101`.check_user WHERE user_id = @user_id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", userId);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                MessageBox.Show("이미 사용 중인 중복된 ID입니다.", "중복 확인");
                                unique = 0;
                            }
                            else
                            {
                                MessageBox.Show("사용 가능한 ID입니다.", "중복 확인");
                                unique = 1;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("중복 확인 중 오류 발생:\n" + ex.Message, "오류");
                unique = 0;
            }
        }
    }
}
