﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.PerformanceData;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;
using Google.Protobuf;

namespace 과제4
{
    public partial class Form3 : Form
    {
        private string good = "Y2l2aWw1OTQ5";
        Form1 f1;
        string connStr;
        public int isLogin_mode; //0: 로그인 1:회원가입
        
        public Form3()
        {
            InitializeComponent();
            InitString();
            isLogin_mode = 0;
        }
        public Form3(Form1 f)
        {
            InitializeComponent();
            InitString();
            isLogin_mode = 0;
            f1 = f;
            this.ActiveControl = login;
        }
        private void InitString()
        {
            string p = Encoding.UTF8.GetString(Convert.FromBase64String(good));
            connStr = $"Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd={p}";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (isLogin_mode == 0)
            {
                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();

                        string sql = "select user_pwd,salt from `1101`.check_user WHERE user_id = @user_id";
                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            
                            cmd.Parameters.AddWithValue("@user_id", login.Text);
                            
                            using (MySqlDataReader reader = cmd.ExecuteReader())
                            {

                                if (reader.Read())
                                {
                                    string dbPwd = reader["user_pwd"].ToString();
                                    string salt = reader["salt"].ToString();
                                    string hashPwd = HashPwd(pwd.Text, salt);
                                    if (dbPwd == hashPwd)
                                    {
                                        MessageBox.Show("로그인 성공");
                                        f1.isLogin = 0;
                                        f1.set_id = login.Text;
                                        f1.Show();
                                        this.Close();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("아이디와 비밀번호가 일치하지 않습니다.");
                                }
                            }

                        }
                    }
                }
                catch (MySqlException ex)
                {
                    // MySQL 관련 에러 처리
                    MessageBox.Show("쿼리 실행 중 오류 발생: " + ex.Message);
                }
                catch (Exception ex)
                {
                    // 일반적인 예외 처리
                    MessageBox.Show("예기치 못한 오류: " + ex);
                }

            }
            else if(isLogin_mode == 1)
            {
                try
                {
                    int find_id=-1;
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();
                        string sql = "SELECT user_id FROM `1101`.check_user WHERE user_id = @user_id";
                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@user_id", login.Text);
                            using (MySqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    find_id = 0;
                                }                                
                            }
                        }
                        if (find_id == 0)
                        {
                            MessageBox.Show("중복된 id입니다.");
                            return;
                        }
                        string salt = GenerateSalt();
                        string hashPwd = HashPwd(pwd.Text, salt);
                        sql = "INSERT INTO `1101`.`check_user`(user_id,user_pwd,salt) VALUES(@user_id, @user_pwd,@salt)";
                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            // 파라미터 바인딩
                            cmd.Parameters.AddWithValue("@user_id", login.Text);
                            cmd.Parameters.AddWithValue("@user_pwd", hashPwd);
                            cmd.Parameters.AddWithValue("@salt", salt);
                            // 실행
                            int rowsAffected = cmd.ExecuteNonQuery();
                            MessageBox.Show("성공적으로 등록되었습니다.");
                            Login_mode();
                            
                        }

                    }
                    
                }
                catch (MySqlException ex)
                {
                    // MySQL 관련 에러 처리
                    MessageBox.Show("쿼리 실행 중 오류 발생: " + ex);
                }
                catch (Exception ex)
                {
                    // 일반적인 예외 처리
                    MessageBox.Show("예기치 못한 오류: " + ex.Message);
                }
            }

        }
        
        private string GenerateSalt()
        {
            byte[] b = new byte[32];
            using(var v = RandomNumberGenerator.Create())
            {
                v.GetBytes(b);
            }
            return Convert.ToBase64String(b);
        }
        private string HashPwd(string pwd, string salt)
        {
            using(SHA256 sha = SHA256.Create())
            {
                string saltPwd = pwd + salt;
                byte[] bytes = Encoding.UTF8.GetBytes(saltPwd);
                byte[] hashB = sha.ComputeHash(bytes);

                StringBuilder sb = new StringBuilder();
                foreach(byte b in hashB)
                {
                    sb.Append(b.ToString("x2")); //x2 : 2글자 16진수
                }
                return sb.ToString();
            }
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login_mode();
           
        }
        private void Login_mode()
        {
            if (isLogin_mode == 0)
            {
                label1.Text = "회원가입";
                button1.Text = "회원가입";
                linkLabel1.Text = "로그인";
                isLogin_mode = 1;
            }
            else if (isLogin_mode == 1)
            {
                label1.Text = "로그인";
                button1.Text = "로그인";
                linkLabel1.Text = "회원가입";
                isLogin_mode = 0;

            }
        } 

    }
}
