using Microsoft.VisualBasic.Devices;
using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZstdSharp.Unsafe;
using System.Linq;

namespace 과제4
{
    public partial class Form1 : Form
    {
        ToolStripMenuItem editItem;
        ToolStripMenuItem shareItem;
        ToolStripMenuItem b1Item;
        ToolStripMenuItem aiItem;
        ToolStripMenuItem themeItem;
        ToolStripMenuItem doneItem;
        private string currentTheme = "기본";

        int screenWidth = Screen.PrimaryScreen.Bounds.Width;
        int screenHeight = Screen.PrimaryScreen.Bounds.Height;
        bool find; bool isSorting;
        Form2 f2;
        Form3 f3;
        Form5 f5;

        int progressValue = 0;
        string progressText = "완료된 할 일: 0 / 0";
        int targetProgress = 0;
        System.Windows.Forms.Timer progressTimer = new System.Windows.Forms.Timer();

        public int isLogin; //0: 로그인 1: 로그아웃
        private bool isLoaded = false;
        private string login_id = "";
        string connStr;
        private string good = "Y2l2aWw1OTQ5";
        List<int> approve_idx = new List<int>();
        private ContextMenuStrip m;

        private NotifyIcon deadlineNotifyIcon;
        private bool deadlineNotified = false;

        public Form1()
        {
            InitializeComponent();
            InitString();

            panel_progress.Paint += panel_progress_Paint;
            progressTimer.Interval = 10;
            progressTimer.Tick += ProgressTimer_Tick;

            textBox_today.Text = DateTime.Now.ToString("yyyy-MM-dd");
            isLogin = 1; isSorting = false;

            edit_dialog.BackColor = Color.Gray;
            share.BackColor = Color.Gray;
            button1.BackColor = Color.Gray;
            ai_comment.BackColor = Color.Gray;

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(50, 150);
            this.Size = new Size((int)(screenWidth * 0.4), (int)(screenHeight * 0.8));

            int totalWidth = listView1.ClientSize.Width;

            listView1.Columns[0].Width = (int)(totalWidth * 0.10); // 상태 (10%)
            listView1.Columns[1].Width = (int)(totalWidth * 0.45); // 할 일 (45%)
            listView1.Columns[2].Width = (int)(totalWidth * 0.15); // 기한 (15%)
            listView1.Columns[3].Width = (int)(totalWidth * 0.15); // 우선순위 (15%)
            listView1.Columns[4].Width = (int)(totalWidth * 0.15); // 추가 날짜 (15%)

            deadlineNotifyIcon = new NotifyIcon();
            deadlineNotifyIcon.Icon = SystemIcons.Information;
            deadlineNotifyIcon.Visible = true;
            deadlineNotifyIcon.Text = "체크리스트 알림";

            m = new ContextMenuStrip();

            editItem = (ToolStripMenuItem)m.Items.Add("추가/편집", null, edit_dialog_Click);
            shareItem = (ToolStripMenuItem)m.Items.Add("공유", null, share_Click);
            b1Item = (ToolStripMenuItem)m.Items.Add("통계", null, button1_Click);
            aiItem = (ToolStripMenuItem)m.Items.Add("AI 코멘트", null, ai_comment_Click);
            themeItem = (ToolStripMenuItem)m.Items.Add("테마 설정");
            doneItem = (ToolStripMenuItem)m.Items.Add("완료된 일", null, done_Click);

            themeItem.DropDownItems.Add("기본", null, (s, e) =>
            {
                ChangeTheme("기본");
            });

            themeItem.DropDownItems.Add("검정", null, (s, e) =>
            {
                ChangeTheme("검정");
            });

            themeItem.DropDownItems.Add("파스텔", null, (s, e) =>
            {
                ChangeTheme("파스텔");
            });

            themeItem.DropDownItems.Add("사용자 선택", null, (s, e) =>
            {
                ChangeCustomTheme();
            });

            editItem.BackColor = Color.Gray;
            shareItem.BackColor = Color.Gray;
            b1Item.BackColor = Color.Gray;
            aiItem.BackColor = Color.Gray;
            themeItem.BackColor = Color.Gray;
            doneItem.BackColor = Color.Gray;
            ApplyTheme("기본");
            currentTheme = "기본";
        }

        public string set_id
        {
            set
            {
                login_id = value;
                comboBox1.Items.Clear();
                comboBox1.Items.Add(value);
                comboBox1.SelectedIndex = 0;
                comboBox1.SelectedItem = value;
                label2.Text = value + "님의 체크리스트";
                isLogin = 0;
                login_button.Text = "로그아웃";

                edit_dialog.BackColor = Color.White;
                share.BackColor = Color.White;
                button1.BackColor = Color.White;
                ai_comment.BackColor = Color.White;

                editItem.BackColor = Color.White;
                shareItem.BackColor = Color.White;
                b1Item.BackColor = Color.White;
                aiItem.BackColor = Color.White;
                themeItem.BackColor = Color.White;
                doneItem.BackColor = Color.White;
                AddShareId();

                // 로그인한 사용자의 저장된 테마를 DB에서 불러와 적용
                LoadTheme();

                LoadItems();

                // LoadItems 안의 change_color가 일부 색을 다시 칠할 수 있어서 마지막에 한 번 더 적용
                ApplyTheme(currentTheme);

                System.Windows.Forms.Timer notifyTimer = new System.Windows.Forms.Timer();
                notifyTimer.Interval = 1000;
                notifyTimer.Tick += (s, e) =>
                {
                    notifyTimer.Stop();
                    notifyTimer.Dispose();
                    CheckDeadlineTrayNotification();
                };
                notifyTimer.Start();
            }
        }

        private void InitString()
        {
            string p = Encoding.UTF8.GetString(Convert.FromBase64String(good));
            connStr = $"Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd={p}";
        }
        public void AddShareId()
        {
            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();
                string sql = "select user_id, approve from `1101`.check_share where shared_id = @shared_id";
                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@shared_id", login_id);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        listView1.Items.Clear();
                        approve_idx.Clear();
                        int idx = 1;
                        while (reader.Read())
                        {
                            int approve = Convert.ToInt32(reader["approve"]);
                            string id = Convert.ToString(reader["user_id"]);
                            comboBox1.Items.Add(id);
                            if (approve == 1)
                                approve_idx.Add(idx);
                            idx++;
                        }
                    }
                }
            }
        }

        public void AddToListView(string todo, string dueDate, string priority, string date, object db_id = null, bool isChecked = false)
        {
            ListViewItem item = new ListViewItem("");
            item.SubItems.Add(todo);
            item.SubItems.Add(dueDate);
            item.SubItems.Add(priority);
            item.SubItems.Add(date);
            listView1.Items.Add(item);

            if (db_id != null)
            {
                item.Tag = db_id;
            }
            item.Checked = isChecked;

            // 기본 우선순위 글자 색상 지정 (item.SubItems[3]이 우선순위 열)
            if (priority == "높음")
            {
                item.SubItems[3].ForeColor = Color.Red;
            }
            else if (priority == "중간")
            {
                item.SubItems[3].ForeColor = Color.Yellow;
            }
            else if (priority == "낮음")
            {
                item.SubItems[3].ForeColor = Color.Green;
            }
            change_color();
        }

        private void LoadItems()
        {

            if (string.IsNullOrEmpty(login_id))
            {
                listView1.Items.Clear();
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    string sql = "select id_check_ToDo, todo, period, priority, status, dateTime from `1101`.check_ToDo where user_id = @user_id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", comboBox1.SelectedItem);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            listView1.Items.Clear();
                            while (reader.Read())
                            {
                                object db_id = reader["id_check_ToDo"];
                                string todo = Convert.ToString(reader["todo"]);
                                string dueDate = Convert.ToString(reader["period"]);
                                string date = Convert.ToDateTime(reader["dateTime"]).ToString("yyyy-MM-dd");

                                string priorityStr = "중간";
                                int p = Convert.ToInt32(reader["priority"]);
                                if (p == 1) priorityStr = "높음";
                                else if (p == 3) priorityStr = "낮음";

                                bool isChecked = Convert.ToString(reader["status"]) == "완료";

                                AddToListView(todo, dueDate, priorityStr, date, db_id, isChecked);
                            }
                        }
                    }
                }
                updateCheck();
                change_color();
            }
            catch (Exception e)
            {
                MessageBox.Show("데이터를 가져오는 중 오류가 발생했습니다:\n" + e, "오류");
            }
            finally
            {
                isLoaded = false;
            }

            foreach (ColumnHeader col in listView1.Columns)
            {
                col.Width = -2;
            }
        }

        private void OpenOrActivateForm2(Size? customSize = null)
        {
            if (isLogin == 1 || string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인이 필요한 service입니다.");
                return;
            }
            f2 = Application.OpenForms["Form2"] as Form2;

            if (f2 == null || f2.IsDisposed)
            {
                f2 = new Form2(this, login_id);
                f2.StartPosition = FormStartPosition.Manual;
                f2.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                if (customSize.HasValue) f2.Size = customSize.Value;

                f2.FormClosed += (s, args) => { f2 = null; };
                f2.Show();
            }
            else
            {
                f2.StartPosition = FormStartPosition.Manual;
                f2.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                if (customSize.HasValue) f2.Size = customSize.Value;

                f2.Activate();
            }
        }

        private void edit_dialog_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != 0)
                return;

            OpenOrActivateForm2(new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.20)));

            if (f2 != null)
            {
                f2.SetMainPenel = true;
                f2.SetPenel = false;
            }
        }

        private string GetChosung(string value)
        {
            char[] chosungs = { 'ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ' };

            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            foreach (char c in value)
            {
                if (c >= 0xAC00 && c <= 0xD7A3)
                {
                    int chosungIndex = (c - 0xAC00) / 28 / 21;
                    sb.Append(chosungs[chosungIndex]);
                }
                else
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }
        private void search_button_Click(object sender, EventArgs e)
        {
            string s = textBox_search.Text.Trim();
            if (string.IsNullOrWhiteSpace(s))
            {
                MessageBox.Show("검색어를 입력해주세요.");
                return;
            }
            find = false;
            string searchChosung = GetChosung(s);

            foreach (ListViewItem item in listView1.Items)
            {
                string targetText = item.SubItems[1].Text;
                string targetChosung = GetChosung(targetText);

                if (targetText.Contains(s) || targetChosung.Contains(searchChosung))
                {
                    find = true;
                    item.SubItems[1].BackColor = Color.FromArgb(189, 252, 201);
                    item.SubItems[1].ForeColor = Color.Black;
                    item.EnsureVisible();
                }
            }
            if (!find)
            {
                MessageBox.Show($"{s} 가 포함된 항목이 없습니다.");
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                string secondColumn = item.SubItems[1].Text;
                string thirdColumn = item.SubItems[2].Text;
                string forthColumn = item.SubItems[3].Text;
                if (f2 != null)
                {
                    f2.SetToDo = secondColumn;
                    f2.SetDate = (DateTime.Parse(thirdColumn) > DateTime.Today) ? thirdColumn : (DateTime.Today).ToString();
                    f2.SetSelect = forthColumn;
                    f2.SetItem = item;
                }
            }
        }



        private int sortColumn = -1;
        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            isSorting = true;
            if (e.Column == sortColumn)
            {
                if (listView1.Sorting == SortOrder.Ascending)
                    listView1.Sorting = SortOrder.Descending;
                else
                    listView1.Sorting = SortOrder.Ascending;
            }
            else
            {
                sortColumn = e.Column;
                listView1.Sorting = SortOrder.Ascending;
            }

            listView1.ListViewItemSorter = new ListViewItemComparer(sortColumn, listView1.Sorting);
            listView1.Sort();
            isSorting = false;
        }

        public void updateCheck()
        {
            int total = listView1.Items.Count;
            int count = listView1.CheckedItems.Count;

            progressText = $"완료된 할 일: {count} / {total}";

            if (total > 0)
            {
                targetProgress = (int)((double)count / total * 100);
                progressTimer.Start();
            }
            else
            {
                progressValue = 0;
            }

            panel_progress.Invalidate();
        }

        private void listView1_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (isLoaded) return;
            
            if (!find)
                change_color();
            updateCheck();
            if (e.Item != null && e.Item.Tag != null)
            {
                object db_id = e.Item.Tag;
                string newStatus = e.Item.Checked ? "완료" : "미완료";

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();
                        string sql = "update `1101`.check_ToDo set status = @status where id_check_ToDo = @id";

                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@status", newStatus);
                            cmd.Parameters.AddWithValue("@id", db_id);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("체크 상태 변경 중 DB 오류 발생: " + ex.Message, "오류");
                }
            }
        }

        private void textBox_search_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_search.Text))
            {
                foreach (ListViewItem item in listView1.Items)
                {
                    item.BackColor = Color.White;
                    find = false;
                }
                change_color();
            }
        }

        private void share_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != 0)
                return;

            OpenOrActivateForm2(new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.25)));

            if (f2 != null)
            {
                f2.SetMainPenel = true;
                f2.SetPenel = true;
            }
        }
        

        private void login_button_Click(object sender, EventArgs e)
        {
            if (isLogin == 0)
            {
                DialogResult result = MessageBox.Show(
                    "로그아웃을 하시겠습니까?",
                    "경고",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Warning
                );
                if (result == DialogResult.OK)
                {
                    MessageBox.Show("로그아웃 되었습니다.");
                    login_button.Text = "로그인/회원가입";
                    label2.Text = "체크리스트";

                    ApplyTheme("기본");
                    currentTheme = "기본";

                    listView1.Items.Clear();
                    comboBox1.Items.Clear();
                    comboBox1.Text = "";
                    isLogin = 1;
                    edit_dialog.BackColor = Color.Gray;
                    share.BackColor = Color.Gray;
                    button1.BackColor = Color.Gray;
                    ai_comment.BackColor = Color.Gray;

                    editItem.BackColor = Color.Gray;
                    shareItem.BackColor = Color.Gray;
                    b1Item.BackColor = Color.Gray;
                    aiItem.BackColor = Color.Gray;
                    themeItem.BackColor = Color.Gray;
                    doneItem.BackColor = Color.Gray;

                    if (f2 != null && !f2.IsDisposed)
                    {
                        f2.DeletePicture = true;
                        f2.Close();
                        f2 = null;
                    }
                    progressValue = 0;
                    targetProgress = 0;
                    progressText = "완료된 할 일: 0 / 0";
                    if (progressTimer.Enabled)
                    {
                        progressTimer.Stop();
                    }
                    panel_progress.Invalidate();
                }
                else if (result == DialogResult.Cancel)
                {

                }
                return;
            }
            Form existingForm = Application.OpenForms["Form3"];

            if (existingForm == null)
            {
                Form3 f3 = new Form3(this);
                f3.StartPosition = FormStartPosition.Manual;
                f3.Size = new Size(480, 250);
                //f3.Size = new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.2));
                f3.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                f3.Show();
            }
            else
            {
                existingForm.StartPosition = FormStartPosition.Manual;
                existingForm.Size = new Size(480, 250);
                existingForm.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                existingForm.Activate();
            }
        }

        private void change_color()
        {
            if (isSorting)
                return;

            foreach (ListViewItem item in listView1.Items)
            {
                item.UseItemStyleForSubItems = true;

                string targetPeriodStr = "";
                foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                {
                    if (DateTime.TryParse(subItem.Text.Trim(), out _))
                    {
                        // 우선순위 열 등과 겹치지 않게 하이픈(-)이 포함된 날짜 형식을 우선 선택
                        if (subItem.Text.Contains("-"))
                        {
                            targetPeriodStr = subItem.Text.Trim();
                            break;
                        }
                    }
                }



                if (DateTime.TryParse(targetPeriodStr, out DateTime period))
                {
                    DateTime today = DateTime.Today;
                    TimeSpan t = period.Date - today;
                    int remain = t.Days;
                    item.UseItemStyleForSubItems = false;
                    if (item.SubItems.Count > 1)
                    {
                        if (item.Checked)
                        {
                            item.SubItems[1].BackColor = Color.White;
                            item.SubItems[1].ForeColor = Color.Black;
                        }
                        else if (remain < 0)
                        {
                            item.SubItems[1].BackColor = Color.DimGray;
                            item.SubItems[1].ForeColor = Color.White;
                        }
                        else if (remain == 0)
                        {
                            item.SubItems[1].BackColor = Color.Red;
                            item.SubItems[1].ForeColor = Color.White;
                        }
                        else if (remain <= 3)
                        {
                            item.SubItems[1].BackColor = Color.Tomato;
                            item.SubItems[1].ForeColor = Color.Black;
                        }
                        else if (remain <= 7)
                        {
                            item.SubItems[1].BackColor = Color.Orange;
                            item.SubItems[1].ForeColor = Color.Black;
                        }
                        else if (remain <= 14)
                        {
                            item.SubItems[1].BackColor = Color.Yellow;
                            item.SubItems[1].ForeColor = Color.Black;
                        }
                        else
                        {
                            item.SubItems[1].BackColor = Color.White;
                            item.SubItems[1].ForeColor = Color.Black;
                        }
                    }

                    if (item.BackColor == Color.Red || item.BackColor == Color.DimGray || item.BackColor == Color.Tomato || item.BackColor == Color.Orange)
                    {
                        foreach (ListViewItem.ListViewSubItem sub in item.SubItems)
                        {
                            sub.ForeColor = Color.White;
                        }
                    }
                    else
                    {
                        string priority = "";
                        foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                        {
                            if (subItem.Text == "높음" || subItem.Text == "중간" || subItem.Text == "낮음")
                            {
                                priority = subItem.Text;
                                subItem.ForeColor = (priority == "높음") ? Color.Red : (priority == "중간") ? Color.Orange : Color.Green;
                                break;
                            }
                        }
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (f2 != null && !f2.IsDisposed)
            {
                f2.Close();
                f2 = null;
            }

            if (comboBox1.SelectedIndex != 0)
            {
                edit_dialog.BackColor = Color.Gray;
                share.BackColor = Color.Gray;
                ai_comment.BackColor = Color.Gray;

                aiItem.BackColor = Color.Gray;
                editItem.BackColor = Color.Gray;
                shareItem.BackColor = Color.Gray;
                
            }
            else
            {
                edit_dialog.BackColor = Color.White;
                share.BackColor = Color.White;
                ai_comment.BackColor = Color.White;

                aiItem.BackColor = Color.White;
                editItem.BackColor = Color.White;
                shareItem.BackColor = Color.White;
                label2.Text = login_id + "님의 체크리스트";
                LoadItems();
                return;
            }
            int approve = -1;
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    string sql = "SELECT approve, requester_id FROM `1101`.check_share WHERE user_id = @login_id AND shared_id = @select_item";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@select_item", comboBox1.SelectedItem);
                        cmd.Parameters.AddWithValue("@login_id", login_id);
                        string requester = null;
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                object myObj = reader["approve"];
                                object myRequester = reader["requester_id"];
                                approve = Convert.ToInt32(Convert.ToDouble(myObj));
                                requester = myRequester.ToString();
                            }
                        }
                        if (approve == 1 && requester != login_id)
                        {

                            DialogResult result = MessageBox.Show(
                                $"{comboBox1.SelectedItem}님의 공유 요청을 승인하시겠습니까?",
                                "공유 승인 요청",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question
                            );

                            if (result == DialogResult.Yes)
                            {
                                approve = 0;
                                approve_idx.Remove(comboBox1.SelectedIndex);
                            }
                            else if (result == DialogResult.No)
                            {
                                MessageBox.Show("요청을 거절했습니다.", "알림");
                            }
                            if (approve == 0)
                            {
                                string updateSql = @"
                                            UPDATE `1101`.check_share 
                                            SET approve = 0 
                                            WHERE (user_id = @login_id AND shared_id = @select_item)
                                               OR (user_id = @select_item AND shared_id = @login_id)";
                                using (MySqlCommand updateCmd = new MySqlCommand(updateSql, conn))
                                {
                                    updateCmd.Parameters.AddWithValue("@select_item", comboBox1.SelectedItem);
                                    updateCmd.Parameters.AddWithValue("@login_id", login_id);

                                    int rows = updateCmd.ExecuteNonQuery();
                                    if (rows > 0)
                                    {
                                        MessageBox.Show("성공적으로 승인되었습니다.", "알림");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("체크 상태 변경 중 DB 오류 발생: " + ex.Message, "오류");
            }
            if (approve == 0)
            {
                //MessageBox.Show("불러오는데 성공하였습니다.", "알림");
                string id = comboBox1.SelectedItem.ToString();
                label2.Text = id + "님의 체크리스트";
                LoadItems();
            }
            else
            {
                MessageBox.Show("불러오는데 실패하였습니다.", "알림");
                listView1.Items.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (isLogin == 1)
                return;

            OpenOrActivateForm2(new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.6)));
            f2.SetMainPenel = false;
            f2.SetPenel = false;
            f2.SetPenel2 = true;

            int[] data = new int[2];
            string[] labels = { "내 완료율", "전체 평균 완료율" };

            string query = @"
                SELECT 
                    IFNULL(ROUND(AVG(CASE WHEN t.status = '완료' THEN 1.0 ELSE 0.0 END) * 100, 1), 0.0) AS my_rate,
                    IFNULL(ROUND(MAX(total.avg_rate) * 100, 1), 0.0) AS total_avg_rate
                FROM (SELECT @user_id AS user_id) dummy
                LEFT JOIN check_ToDo t ON t.user_id = dummy.user_id
                CROSS JOIN (
                    SELECT AVG(CASE WHEN status = '완료' THEN 1.0 ELSE 0.0 END) AS avg_rate
                    FROM check_ToDo
                ) total";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", comboBox1.SelectedItem);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                object myRateObj = reader["my_rate"];
                                object totalRateObj = reader["total_avg_rate"];

                                data[0] = (myRateObj != DBNull.Value) ? Convert.ToInt32(Convert.ToDouble(myRateObj)) : 0;
                                data[1] = (totalRateObj != DBNull.Value) ? Convert.ToInt32(Convert.ToDouble(totalRateObj)) : 0;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DB 연결 중 오류 발생: {ex.Message}");
                return;
            }

            DrawMiniChart(data, labels, 100);
        }

        private void DrawMiniChart(int[] data, string[] labels, int maxValue)
        {
            // 현재 pictureBox1의 실제 크기
            int pBoxWidth = f2.pictureBox1.Width;
            int pBoxHeight = f2.pictureBox1.Height;

            // 예외 방지: 크기가 너무 작으면 그리지 않음
            if (pBoxWidth <= 0 || pBoxHeight <= 0) return;

            Bitmap bmp = new Bitmap(pBoxWidth, pBoxHeight);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.FromArgb(245, 245, 245));

                // 여백을 전체 높이/너비의 비율로 설정하여 해상도 대응
                int marginX = (int)(pBoxWidth * 0.12);
                int marginY = (int)(pBoxHeight * 0.15);

                int chartWidth = pBoxWidth - (marginX * 2);
                int chartHeight = pBoxHeight - (marginY * 2);

                // 막대 너비와 글꼴 크기도 전체 크기에 비례하도록 설정
                int barWidth = chartWidth / 4;
                float fontSize = Math.Max(9, pBoxHeight * 0.04f);

                using (Font textFont = new Font("맑은 고딕", fontSize, FontStyle.Regular))
                using (Font valueFont = new Font("맑은 고딕", fontSize + 1, FontStyle.Bold))
                {
                    Brush[] barBrushes = { Brushes.Blue, Brushes.DarkGray };

                    for (int i = 0; i < data.Length; i++)
                    {
                        // 각 막대의 중심 X 좌표 계산
                        int x = marginX + (i * (chartWidth / 2)) + (chartWidth / 4) - (barWidth / 2);

                        // 데이터 비율 계산
                        int barHeight = (int)((double)data[i] / maxValue * chartHeight);
                        int y = pBoxHeight - marginY - barHeight;

                        // 막대 그리기
                        g.FillRectangle(barBrushes[i], x, y, barWidth, barHeight);
                        g.DrawRectangle(Pens.Black, x, y, barWidth, barHeight);

                        StringFormat sf = new StringFormat();
                        sf.Alignment = StringAlignment.Center;

                        // 하단 레이블
                        g.DrawString(labels[i], textFont, Brushes.Black, x + (barWidth / 2), pBoxHeight - marginY + (marginY * 0.2f), sf);

                        // 상단 퍼센트
                        g.DrawString($"{data[i]}%", valueFont, Brushes.Black, x + (barWidth / 2), y - (marginY * 0.9f), sf);
                    }
                }
                g.DrawLine(Pens.Black, marginX, pBoxHeight - marginY, pBoxWidth - marginX, pBoxHeight - marginY);
            }

            f2.pictureBox1.Image = bmp;
        }

        private void listView1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (isLoaded) return;
            if (comboBox1.SelectedIndex != 0)
            {
                if (listView1.FocusedItem != null)
                {
                    e.NewValue = e.CurrentValue;
                }
            }
        }

        private void panel_progress_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            int width = panel_progress.Width;
            int height = panel_progress.Height;

            g.FillRectangle(Brushes.LightGray, 0, 0, width, height);

            int progressWidth = (int)((progressValue / 100.0) * width);

            g.FillRectangle(Brushes.LimeGreen, 0, 0, progressWidth, height);
            g.DrawRectangle(Pens.Gray, 0, 0, width - 1, height - 1);

            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;

            using (Font progressFont = new Font("맑은 고딕", 10, FontStyle.Bold))
            {
                g.DrawString(progressText, progressFont, Brushes.Black, new RectangleF(0, 0, width, height), sf);
            }
        }

        private void ProgressTimer_Tick(object sender, EventArgs e)
        {
            if (progressValue < targetProgress)
            {
                progressValue++;
            }
            else if (progressValue > targetProgress)
            {
                progressValue--;
            }
            else
            {
                progressTimer.Stop();
            }

            panel_progress.Invalidate();
        }
        public void deleteItems()
        {
            int c = listView1.SelectedItems.Count;
            if (c > 0)
            {
                for (int i = c - 1; i >= 0; i--)
                {
                    listView1.Items.Remove(listView1.SelectedItems[i]);
                }
            }
        }
        public void deleteItem_db(ListViewItem item)
        {
            DialogResult result = MessageBox.Show("정말 삭제하시겠습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result != DialogResult.Yes)
                return;

            string todo = item.SubItems[1].Text;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    string sql = "delete from `1101`.check_ToDo where user_id = @user_id and todo = @todo";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", login_id);
                        cmd.Parameters.AddWithValue("@todo", todo);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("DB에서 성공적으로 삭제되었습니다.", "알림");
                    }
                }
                listView1.Items.Remove(item);
                updateCheck();
                if (f2 != null && !f2.IsDisposed)
                {
                    f2.clearItems();
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("삭제 중 오류 발생: " + e.Message, "오류");
            }

        }
        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                ListViewItem item = listView1.GetItemAt(e.X, e.Y);
                if (item != null)
                {

                    if (comboBox1.SelectedIndex != 0)
                    {
                        MessageBox.Show("다른 사람의 할 일은 변경할 수 없습니다.", "알림");
                        return;
                    }
                    ContextMenuStrip menu = new ContextMenuStrip();
                    var editMenu = menu.Items.Add("수정");
                    editMenu.Click += edit_dialog_Click;
                    var deleteMenu = menu.Items.Add("삭제");
                    deleteMenu.Click += (s, ev) => deleteItem_db(item);

                    menu.Show(listView1, e.Location);
                }
            }
        }

        private void comboBox1_DrawItem(object sender, DrawItemEventArgs e)
        {
            // 잘못된 인덱스거나 아이템이 없으면 무시
            if (e.Index < 0) return;

            ComboBox combo = sender as ComboBox;

            Color backColor = Color.White;
            Color textColor = Color.Black;

            foreach (int idx in approve_idx)
            {
                if (e.Index == idx)
                {
                    backColor = Color.LightGray;
                    textColor = Color.Black;
                }
            }

            // 마우스가 올라가 있거나 선택된 상태(포커스)일 때의 기본 하이라이트 배경색 처리
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
            {
                backColor = SystemColors.Highlight;
                textColor = SystemColors.HighlightText;
            }

            // 배경 그리기
            using (SolidBrush backBrush = new SolidBrush(backColor))
            {
                e.Graphics.FillRectangle(backBrush, e.Bounds);
            }

            // 텍스트 그리기
            using (SolidBrush textBrush = new SolidBrush(textColor))
            {
                string text = combo.Items[e.Index].ToString();
                // 텍스트가 사각형 중앙 왼쪽 근처에 예쁘게 위치하도록 정렬
                e.Graphics.DrawString(text, e.Font, textBrush, e.Bounds, StringFormat.GenericDefault);
            }

            // 포커스 표시선 그리기 (선택되었을 때 테두리 점선)
            e.DrawFocusRectangle();
        }

        private void ai_comment_Click(object sender, EventArgs e)
        {
            if (isLogin == 1 || string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인이 필요한 service입니다.");
                return;
            }
            if (comboBox1.SelectedIndex != 0)
            {
                MessageBox.Show("나의 테이블의 코멘트만 받을 수 있습니다.");
                return;
            }
            Form existingForm = Application.OpenForms["Form4"];
            if (existingForm == null)
            {
                Form4 f4 = new Form4(this, login_id);
                f4.StartPosition = FormStartPosition.Manual;
                f4.Size = new Size(480, 250);
                f4.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                f4.Show();
            }
            else
            {
                existingForm.StartPosition = FormStartPosition.Manual;
                existingForm.Size = new Size(480, 250);
                existingForm.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                existingForm.Activate();
            }
        }
        private void done_Click(object sender, EventArgs e)
        {
            if (isLogin == 1 || string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인이 필요한 service입니다.");
                return;
            }

            f5 = Application.OpenForms["Form5"] as Form5;
            if (f5 == null || f5.IsDisposed)
            {
                f5 = new Form5(this, login_id);
                f5.StartPosition = FormStartPosition.Manual;
                
                f5.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                f5.Show();
            }
            else
            {
                f5.StartPosition = FormStartPosition.Manual;
                f5.Size = new Size(480, 400);
                f5.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                f5.Activate();
            }

        }
        private void menu_button_Click(object sender, EventArgs e)
        {
            m.Show(menu_button, new Point(0, menu_button.Height));
        }


        private void CheckDeadlineTrayNotification()
        {
            if (deadlineNotified) return;

            List<string> deadlineList = new List<string>();

            foreach (ListViewItem item in listView1.Items)
            {
                string todo = item.SubItems[1].Text;
                string dueDate = item.SubItems[2].Text;

                if (DateTime.TryParse(dueDate, out DateTime period))
                {
                    int remain = (period.Date - DateTime.Today).Days;

                    if (remain >= 0 && remain <= 1)
                    {
                        deadlineList.Add($"{todo} (D-{remain})");
                    }
                }
            }

            if (deadlineList.Count > 0)
            {
                int count = deadlineList.Count;

                string msg = string.Join("\n", deadlineList.Take(5));

                MessageBox.Show(
                    $"마감 임박 일정이 {count}건 있습니다.\n\n{msg}",
                    "마감 임박 알림",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                deadlineNotifyIcon.Visible = true;
                deadlineNotifyIcon.BalloonTipTitle = "마감 임박 알림";
                deadlineNotifyIcon.BalloonTipText = msg;
                deadlineNotifyIcon.BalloonTipIcon = ToolTipIcon.Warning;
                deadlineNotifyIcon.ShowBalloonTip(5000);

                deadlineNotified = true;
            }
        }



        private void ChangeTheme(string theme)
        {
            if (isLogin == 1 || string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인 후 테마를 변경할 수 있습니다.");
                return;
            }

            currentTheme = theme;
            ApplyTheme(theme);
            SaveTheme(theme);
        }

        private void ChangeCustomTheme()
        {
            if (isLogin == 1 || string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인 후 테마를 변경할 수 있습니다.");
                return;
            }

            using (ColorDialog colorDialog = new ColorDialog())
            {
                colorDialog.FullOpen = true;

                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    Color selectedColor = colorDialog.Color;

                    // DB의 theme 컬럼 varchar(20)에 저장 가능한 형식
                    // 예: 사용자:255,200,150
                    string themeValue = $"사용자:{selectedColor.R},{selectedColor.G},{selectedColor.B}";

                    currentTheme = themeValue;
                    ApplyTheme(themeValue);
                    SaveTheme(themeValue);
                }
            }
        }

        private void SaveTheme(string theme)
        {
            if (string.IsNullOrEmpty(login_id)) return;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();

                    string sql = "UPDATE `1101`.check_user SET theme = @theme WHERE user_id = @user_id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@theme", theme);
                        cmd.Parameters.AddWithValue("@user_id", login_id);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("테마 저장 중 오류 발생: " + ex.Message, "오류");
            }
        }

        private void LoadTheme()
        {
            if (string.IsNullOrEmpty(login_id))
            {
                currentTheme = "기본";
                ApplyTheme("기본");
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();

                    string sql = "SELECT theme FROM `1101`.check_user WHERE user_id = @user_id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", login_id);

                        object result = cmd.ExecuteScalar();

                        if (result == null || result == DBNull.Value || string.IsNullOrWhiteSpace(result.ToString()))
                        {
                            currentTheme = "기본";
                        }
                        else
                        {
                            currentTheme = result.ToString();
                        }

                        ApplyTheme(currentTheme);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("테마 불러오기 중 오류 발생: " + ex.Message, "오류");
                currentTheme = "기본";
                ApplyTheme("기본");
            }
        }

        private void ApplyTheme(string theme)
        {
            if (listView1 == null || panel_progress == null) return;

            if (string.IsNullOrWhiteSpace(theme))
                theme = "기본";

            if (theme == "기본")
            {
                this.BackColor = Color.White;
                listView1.BackColor = Color.White;
                listView1.ForeColor = Color.Black;
                panel_progress.BackColor = Color.LightGray;
                menu_button.BackColor = Color.White;
                menu_button.ForeColor = Color.Black;
            }
            else if (theme == "검정")
            {
                this.BackColor = Color.FromArgb(40, 40, 40);
                listView1.BackColor = Color.FromArgb(55, 55, 55);
                listView1.ForeColor = Color.White;
                panel_progress.BackColor = Color.DimGray;
                menu_button.BackColor = Color.FromArgb(55, 55, 55);
                menu_button.ForeColor = Color.White;
            }
            else if (theme == "파스텔")
            {
                this.BackColor = Color.FromArgb(255, 245, 250);
                listView1.BackColor = Color.FromArgb(255, 250, 240);
                listView1.ForeColor = Color.Black;
                panel_progress.BackColor = Color.FromArgb(230, 230, 250);
                menu_button.BackColor = Color.FromArgb(255, 240, 245);
                menu_button.ForeColor = Color.Black;
            }
            else if (theme.StartsWith("사용자:"))
            {
                Color userColor = Color.White;

                try
                {
                    string rgb = theme.Replace("사용자:", "");
                    string[] parts = rgb.Split(',');

                    if (parts.Length == 3)
                    {
                        int r = Convert.ToInt32(parts[0]);
                        int g = Convert.ToInt32(parts[1]);
                        int b = Convert.ToInt32(parts[2]);

                        userColor = Color.FromArgb(r, g, b);
                    }
                }
                catch
                {
                    userColor = Color.White;
                }

                this.BackColor = userColor;
                listView1.BackColor = ControlPaint.Light(userColor);
                listView1.ForeColor = Color.Black;
                panel_progress.BackColor = ControlPaint.LightLight(userColor);
                menu_button.BackColor = ControlPaint.Light(userColor);
                menu_button.ForeColor = Color.Black;
            }

            if (listView1.Items.Count > 0)
            {
                change_color();
            }

            panel_progress.Invalidate();
        }

        
    }
}

public class ListViewItemComparer : IComparer
{
    private int col;
    private SortOrder order;

    public ListViewItemComparer(int column, SortOrder order)
    {
        col = column;
        this.order = order;
    }

    public int Compare(object x, object y)
    {

        ListViewItem itemX = (ListViewItem)x;
        ListViewItem itemY = (ListViewItem)y;

        string textX = ((ListViewItem)x).SubItems[col].Text;
        string textY = ((ListViewItem)y).SubItems[col].Text;

        int result;
        if (col == 0) {
            if (itemX.Checked && !itemY.Checked)
            {
                result = -1;
            }
            else if (!itemX.Checked && itemY.Checked)
            {
                result = 1;
            }
            else
            {
                result = String.Compare(textX, textY);
            }
        }
        else if (col == 3)
        {
            string[] order_list = { "낮음", "중간", "높음" };
            int indexX = Array.IndexOf(order_list, textX);
            int indexY = Array.IndexOf(order_list, textY);
            result = indexX.CompareTo(indexY);
        }
        else
        {
            result = String.Compare(textX, textY);
        }

        return order == SortOrder.Ascending ? result : -result;
    }
}