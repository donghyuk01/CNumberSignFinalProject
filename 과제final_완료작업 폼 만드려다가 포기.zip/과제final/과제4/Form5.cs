﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace 과제4
{
    public partial class Form5 : Form
    {
        private string good = "Y2l2aWw1OTQ5";
        Form1 f1;
        private string login_id;
        private bool isLoaded = false;
        string connStr;
        public Form5()
        {
            InitializeComponent();
            InitString();
        }
        public Form5(Form1 f, string user_id)
        {
            InitializeComponent();
            InitString();
            listView1.CheckBoxes = true;
            this.f1 = f;
            this.login_id = user_id;
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            LoadItems();
        }
        private void LoadItems()
        {
            if (string.IsNullOrEmpty(login_id)) return;
            isLoaded = true;;

        }
        private void home_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void InitString()
        {
            string p = Encoding.UTF8.GetString(Convert.FromBase64String(good));
            connStr = $"Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd={p}";
        }
    }
}
