﻿namespace 과제4
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            check = new ColumnHeader();
            todo = new ColumnHeader();
            date = new ColumnHeader();
            panel1 = new Panel();
            label1 = new Label();
            home_button = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new ColumnHeader[] { check, todo, date });
            listView1.Dock = DockStyle.Fill;
            listView1.Location = new Point(0, 63);
            listView1.Name = "listView1";
            listView1.Size = new Size(1128, 686);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            // 
            // check
            // 
            check.Text = "상태";
            check.Width = 70;
            // 
            // todo
            // 
            todo.Text = "할 일";
            todo.TextAlign = HorizontalAlignment.Center;
            todo.Width = 750;
            // 
            // date
            // 
            date.Text = "추가 날짜";
            date.TextAlign = HorizontalAlignment.Center;
            date.Width = 310;
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Controls.Add(home_button);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1128, 63);
            panel1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            label1.Location = new Point(100, 9);
            label1.Name = "label1";
            label1.Size = new Size(84, 45);
            label1.TabIndex = 1;
            label1.Text = "작업";
            // 
            // home_button
            // 
            home_button.Location = new Point(12, 5);
            home_button.Name = "home_button";
            home_button.Size = new Size(64, 52);
            home_button.TabIndex = 0;
            home_button.Text = "⌂";
            home_button.UseVisualStyleBackColor = true;
            home_button.Click += home_button_Click;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(14F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1128, 749);
            Controls.Add(listView1);
            Controls.Add(panel1);
            Name = "Form5";
            Text = "Form5";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private ListView listView1;
        private Panel panel1;
        private Button home_button;
        private ColumnHeader check;
        private ColumnHeader todo;
        private ColumnHeader date;
        private Label label1;
    }
}