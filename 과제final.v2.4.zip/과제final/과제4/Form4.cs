﻿using GenerativeAI;
using MySql.Data.MySqlClient;
using System;
using System.Drawing; // Graphics, Font, Brushes 사용을 위해 필요
using System.Text;
using System.Windows.Forms;

namespace 과제4
{
    public partial class Form4 : Form
    {
        Form1 f1;
        string connStr;
        private string login_id = "";
        private string good = "Y2l2aWw1OTQ5";
        private const string ApiKey = "AQ.Ab8RN6JV7jUj671mJ2IPciub2E--hniJMMeFKSOhBr01NQNryQ";

        // [추가] 패널에 그려줄 텍스트를 저장할 전역 변수
        private string panelText = "";

        public Form4()
        {
            InitializeComponent();
            InitString();
        }

        public Form4(Form1 f)
        {
            InitializeComponent();
            f1 = f;
            InitString();
            ai_comment();
            
        }

        public Form4(Form1 f, string user_id)
        {
            InitializeComponent();
            InitString();
            f1 = f;
            login_id = user_id;
            ai_comment();
        }

        private void InitString()
        {
            string p = Encoding.UTF8.GetString(Convert.FromBase64String(good));
            connStr = $"Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd={p}";
        }

        private async void ai_comment()
        {
            try
            {
                if (f1 != null && f1.ai_comment != null)
                {
                    f1.ai_comment.Enabled = false;
                }

                // [수정] 텍스트박스 대신 패널 텍스트 변수를 바꾸고 패널을 새로고침(Invalidate)합니다.
                panelText = "Gemini가 데이터를 분석하고 있습니다. 잠시만 기다려주세요...";
                panel1.Invalidate();

                string prompt = null;

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        await conn.OpenAsync();
                        string sql = "SELECT status, todo, period, priority, dateTime FROM `1101`.check_ToDo WHERE user_id = @user_id";

                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@user_id", login_id);

                            using (MySqlDataReader reader = (MySqlDataReader)await cmd.ExecuteReaderAsync())
                            {
                                prompt = "당신은 자기계발 코치이자 마케팅 전문가입니다.  " +
                                         "아래 Todo 리스트를 분석하여 사용자를 격려하고 우선순위에 대한 조언을 친절하게 2~3문장으로 해주세요."+
                                         $"오늘 날짜는 {DateTime.Today}입니다.해당 날짜를 참고해서 조언해주세요\n\n";

                                bool hasData = false;

                                while (await reader.ReadAsync())
                                {
                                    hasData = true;
                                    prompt += $"- 상태: {reader["status"]}, 할일: {reader["todo"]}, 마감: {reader["period"]}, 우선순위: {reader["priority"]}\n";
                                }

                                if (!hasData)
                                {
                                    prompt += "사용자의 할 일 목록이 비어 있습니다. 할 일을 등록하도록 친절하게 독려해주세요.";
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("데이터베이스를 불러오는 중 오류가 발생했습니다:\n" + ex.Message, "DB 오류", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    panelText = "데이터를 불러오지 못해 분석을 시작할 수 없습니다.";
                    panel1.Invalidate();
                    return;
                }

                if (string.IsNullOrEmpty(prompt)) return;

                var model = new GenerativeModel(model: GoogleAIModels.Gemini25Flash, apiKey: ApiKey);
                var response = await model.GenerateContentAsync(prompt);

                // [수정] AI가 답변한 결과를 패널 텍스트 변수에 넣고 새로고침합니다.
                panelText = response.Text;
                panel1.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Gemini API 호출 중 오류가 발생했습니다: {ex.Message}", "AI 에러", MessageBoxButtons.OK, MessageBoxIcon.Error);
                panelText = "코멘트 생성에 실패했습니다.";
                panel1.Invalidate();
            }
            finally
            {
                if (f1 != null && f1.ai_comment != null)
                {
                    f1.ai_comment.Enabled = true;
                }
            }
        }

        // [수정] 비어있던 패널 Paint 이벤트에 글씨를 그리는 로직을 작성합니다.
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            if (string.IsNullOrEmpty(panelText)) return;

            // 패널 내부에서 글씨가 그려질 여백 사각형 구역 설정 (좌우상하 10픽셀 여백)
            Rectangle drawRectangle = new Rectangle(10, 10, panel1.Width - 20, panel1.Height - 20);

            // 폰트 설정 (맑은 고딕, 크기 10, 일반 스타일)
            using (Font myFont = new Font("맑은 고딕", 10, FontStyle.Regular))
            {
                // 안티앨리어싱을 적용하여 글씨 테두리를 부드럽게 만듭니다.
                e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

                // 검은색(Brushes.Black)으로 패널 내부에 지정한 영역만큼 자동 줄바꿈하여 글씨를 그립니다.
                e.Graphics.DrawString(panelText, myFont, Brushes.Black, drawRectangle);
            }
        }
    }
}