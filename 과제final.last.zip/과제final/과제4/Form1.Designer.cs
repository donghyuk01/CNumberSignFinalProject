﻿namespace 과제4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            panel1 = new Panel();
            panel3 = new Panel();
            menu_button = new Button();
            comboBox1 = new ComboBox();
            login_button = new Button();
            label2 = new Label();
            panel2 = new Panel();
            status_comboBox = new ComboBox();
            ai_comment = new Button();
            panel_progress = new Panel();
            button1 = new Button();
            share = new Button();
            edit_dialog = new Button();
            label3 = new Label();
            label1 = new Label();
            textBox_today = new TextBox();
            search_button = new Button();
            textBox_search = new TextBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.BackColor = Color.White;
            listView1.CheckBoxes = true;
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4, columnHeader5 });
            listView1.Dock = DockStyle.Fill;
            listView1.FullRowSelect = true;
            listView1.Location = new Point(0, 283);
            listView1.Margin = new Padding(6);
            listView1.Name = "listView1";
            listView1.Size = new Size(1347, 767);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            listView1.ColumnClick += listView1_ColumnClick;
            listView1.ItemCheck += listView1_ItemCheck;
            listView1.ItemChecked += listView1_ItemChecked;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            listView1.MouseClick += listView1_MouseClick;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "상태";
            columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "할 일";
            columnHeader2.TextAlign = HorizontalAlignment.Center;
            columnHeader2.Width = 340;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "기한";
            columnHeader3.TextAlign = HorizontalAlignment.Center;
            columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "우선순위";
            columnHeader4.TextAlign = HorizontalAlignment.Center;
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "추가 날짜";
            columnHeader5.TextAlign = HorizontalAlignment.Center;
            columnHeader5.Width = 100;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gainsboro;
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(6);
            panel1.Name = "panel1";
            panel1.Size = new Size(1347, 74);
            panel1.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.BackColor = Color.SteelBlue;
            panel3.Controls.Add(menu_button);
            panel3.Controls.Add(comboBox1);
            panel3.Controls.Add(login_button);
            panel3.Controls.Add(label2);
            panel3.Location = new Point(1, 0);
            panel3.Margin = new Padding(4);
            panel3.Name = "panel3";
            panel3.Size = new Size(1394, 77);
            panel3.TabIndex = 3;
            // 
            // menu_button
            // 
            menu_button.BackColor = Color.Transparent;
            menu_button.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            menu_button.ImageAlign = ContentAlignment.TopRight;
            menu_button.Location = new Point(1280, 9);
            menu_button.Margin = new Padding(6);
            menu_button.Name = "menu_button";
            menu_button.Size = new Size(76, 67);
            menu_button.TabIndex = 3;
            menu_button.Text = "≡";
            menu_button.TextAlign = ContentAlignment.TopCenter;
            menu_button.UseVisualStyleBackColor = false;
            menu_button.Click += menu_button_Click;
            // 
            // comboBox1
            // 
            comboBox1.DrawMode = DrawMode.OwnerDrawFixed;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(64, 19);
            comboBox1.Margin = new Padding(4, 3, 4, 3);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(292, 40);
            comboBox1.TabIndex = 2;
            comboBox1.DrawItem += comboBox1_DrawItem;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // login_button
            // 
            login_button.FlatStyle = FlatStyle.Flat;
            login_button.ForeColor = Color.White;
            login_button.Location = new Point(960, 13);
            login_button.Margin = new Padding(6);
            login_button.Name = "login_button";
            login_button.Size = new Size(295, 49);
            login_button.TabIndex = 1;
            login_button.Text = "로그인/회원가입";
            login_button.UseVisualStyleBackColor = true;
            login_button.Click += login_button_Click;
            // 
            // label2
            // 
            label2.Font = new Font("맑은 고딕", 14F, FontStyle.Bold, GraphicsUnit.Point, 129);
            label2.ForeColor = Color.White;
            label2.Location = new Point(424, 9);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(505, 60);
            label2.TabIndex = 0;
            label2.Text = "체크리스트";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(status_comboBox);
            panel2.Controls.Add(ai_comment);
            panel2.Controls.Add(panel_progress);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(share);
            panel2.Controls.Add(edit_dialog);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(textBox_today);
            panel2.Controls.Add(search_button);
            panel2.Controls.Add(textBox_search);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 74);
            panel2.Margin = new Padding(6);
            panel2.Name = "panel2";
            panel2.Size = new Size(1347, 209);
            panel2.TabIndex = 2;
            // 
            // status_comboBox
            // 
            status_comboBox.FormattingEnabled = true;
            status_comboBox.Location = new Point(948, 123);
            status_comboBox.Name = "status_comboBox";
            status_comboBox.Size = new Size(207, 40);
            status_comboBox.TabIndex = 13;
            status_comboBox.SelectedIndexChanged += status_comboBox_SelectedIndexChanged;
            // 
            // ai_comment
            // 
            ai_comment.Location = new Point(568, 10);
            ai_comment.Margin = new Padding(1, 3, 1, 3);
            ai_comment.Name = "ai_comment";
            ai_comment.Size = new Size(94, 32);
            ai_comment.TabIndex = 12;
            ai_comment.Text = "ai_comment";
            ai_comment.UseVisualStyleBackColor = true;
            ai_comment.Visible = false;
            ai_comment.Click += ai_comment_Click;
            // 
            // panel_progress
            // 
            panel_progress.Location = new Point(948, 28);
            panel_progress.Margin = new Padding(4);
            panel_progress.Name = "panel_progress";
            panel_progress.Size = new Size(342, 49);
            panel_progress.TabIndex = 11;
            // 
            // button1
            // 
            button1.Location = new Point(679, 10);
            button1.Margin = new Padding(1, 3, 1, 3);
            button1.Name = "button1";
            button1.Size = new Size(64, 33);
            button1.TabIndex = 10;
            button1.Text = "통계";
            button1.UseVisualStyleBackColor = true;
            button1.Visible = false;
            button1.Click += button1_Click;
            // 
            // share
            // 
            share.FlatStyle = FlatStyle.Flat;
            share.Location = new Point(828, 10);
            share.Margin = new Padding(6);
            share.Name = "share";
            share.Size = new Size(48, 33);
            share.TabIndex = 8;
            share.Text = "공유";
            share.UseVisualStyleBackColor = true;
            share.Visible = false;
            share.Click += share_Click;
            // 
            // edit_dialog
            // 
            edit_dialog.FlatStyle = FlatStyle.Flat;
            edit_dialog.Location = new Point(749, 7);
            edit_dialog.Margin = new Padding(6);
            edit_dialog.Name = "edit_dialog";
            edit_dialog.Size = new Size(67, 39);
            edit_dialog.TabIndex = 7;
            edit_dialog.Text = "추가/편집";
            edit_dialog.UseVisualStyleBackColor = true;
            edit_dialog.Visible = false;
            edit_dialog.Click += edit_dialog_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(64, 29);
            label3.Margin = new Padding(6, 0, 6, 0);
            label3.Name = "label3";
            label3.Size = new Size(118, 32);
            label3.TabIndex = 6;
            label3.Text = "오늘 날짜";
            // 
            // label1
            // 
            label1.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            label1.Location = new Point(64, 115);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(57, 49);
            label1.TabIndex = 5;
            label1.Text = "⌕";
            // 
            // textBox_today
            // 
            textBox_today.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox_today.BackColor = SystemColors.MenuBar;
            textBox_today.Location = new Point(195, 28);
            textBox_today.Margin = new Padding(6);
            textBox_today.Name = "textBox_today";
            textBox_today.ReadOnly = true;
            textBox_today.Size = new Size(272, 39);
            textBox_today.TabIndex = 3;
            // 
            // search_button
            // 
            search_button.Anchor = AnchorStyles.Bottom;
            search_button.FlatStyle = FlatStyle.Flat;
            search_button.Location = new Point(749, 118);
            search_button.Margin = new Padding(6);
            search_button.Name = "search_button";
            search_button.Size = new Size(122, 49);
            search_button.TabIndex = 1;
            search_button.Text = "검색";
            search_button.UseVisualStyleBackColor = true;
            search_button.Click += search_button_Click;
            // 
            // textBox_search
            // 
            textBox_search.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox_search.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox_search.Location = new Point(118, 118);
            textBox_search.Margin = new Padding(6);
            textBox_search.Name = "textBox_search";
            textBox_search.Size = new Size(614, 50);
            textBox_search.TabIndex = 0;
            textBox_search.TextChanged += textBox_search_TextChanged;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(14F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1347, 1050);
            Controls.Add(listView1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            ForeColor = Color.Black;
            Margin = new Padding(6);
            MaximumSize = new Size(1373, 1620);
            MinimumSize = new Size(1373, 986);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "체크리스트";
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Panel panel2;
        private TextBox textBox_search;
        private Button search_button;
        private Label label1;
        private TextBox textBox_today;
        private Label label2;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private Label label3;
        private Button edit_dialog;
        public ListView listView1;
        private Button login_button;
        public ComboBox comboBox1;
        private Panel panel3;
        private Button button1;
        private Panel panel_progress;
        private ContextMenuStrip contextMenuStrip1;
        public Button ai_comment;
        private Button menu_button;
        private Button share;
        private ComboBox status_comboBox;
    }
}
