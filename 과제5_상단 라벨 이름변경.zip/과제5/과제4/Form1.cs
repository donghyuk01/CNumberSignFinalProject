using Microsoft.VisualBasic.Devices;
using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace 과제4
{
    public partial class Form1 : Form
    {

        int screenWidth = Screen.PrimaryScreen.Bounds.Width;
        int screenHeight = Screen.PrimaryScreen.Bounds.Height;

        Form2 f2;
        Form3 f3;

        int progressValue = 0;
        string progressText = "완료된 할 일: 0 / 0";
        int targetProgress = 0;
        System.Windows.Forms.Timer progressTimer = new System.Windows.Forms.Timer();

        public int isLogin; //0: 로그인 1: 로그아웃
        private bool isLoaded = false;
        private string login_id = "";
        string connStr;
        private string good = "Y2l2aWw1OTQ5";

        public Form1()
        {
            InitializeComponent();
            InitString();
            panel_progress.Paint += panel_progress_Paint;
            progressTimer.Interval = 10;
            progressTimer.Tick += ProgressTimer_Tick;

            textBox_today.Text = DateTime.Now.ToString("yyyy-MM-dd");
            isLogin = 1;
            edit_dialog.BackColor = Color.Gray;
            share.BackColor = Color.Gray;
            button1.BackColor = Color.Gray;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(50, 150);
            this.Size = new Size((int)(screenWidth * 0.4), (int)(screenHeight * 0.8));

            int totalWidth = listView1.ClientSize.Width;

            listView1.Columns[0].Width = (int)(totalWidth * 0.10); // 상태 (10%)
            listView1.Columns[1].Width = (int)(totalWidth * 0.45); // 할 일 (45%)
            listView1.Columns[2].Width = (int)(totalWidth * 0.15); // 기한 (15%)
            listView1.Columns[3].Width = (int)(totalWidth * 0.15); // 우선순위 (15%)
            listView1.Columns[4].Width = (int)(totalWidth * 0.15); // 추가 날짜 (15%)
        }

        public string set_id
        {
            set
            {
                login_id = value;
                comboBox1.Items.Clear();
                comboBox1.Items.Add(value);
                comboBox1.SelectedIndex = 0;
                comboBox1.SelectedItem = value;
                label2.Text = value + "님의 체크리스트";
                isLogin = 0;
                login_button.Text = "로그아웃";
                edit_dialog.BackColor = Color.White;
                share.BackColor = Color.White;
                button1.BackColor = Color.White;
                AddShareId();
                LoadItems();
            }
        }
        private void InitString()
        {
            string p = Encoding.UTF8.GetString(Convert.FromBase64String(good));
            connStr = $"Server=155.230.235.248;Port=32065;Database=1101;Uid=d1101;Pwd={p}";
        }
        public void AddShareId()
        {
            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();
                string sql = "select user_id from `1101`.check_share where shared_id = @shared_id";
                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@shared_id", login_id);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        listView1.Items.Clear();
                        while (reader.Read())
                        {
                            string id = Convert.ToString(reader["user_id"]);
                            comboBox1.Items.Add(id);
                        }
                    }
                }
            }
        }

        public void AddToListView(string todo, string dueDate, string priority, string date, object db_id = null, bool isChecked = false)
        {
            ListViewItem item = new ListViewItem("");
            item.SubItems.Add(todo);
            item.SubItems.Add(dueDate);
            item.SubItems.Add(priority);
            item.SubItems.Add(date);
            listView1.Items.Add(item);

            if (db_id != null)
            {
                item.Tag = db_id;
            }
            item.Checked = isChecked;

            // 기본 우선순위 글자 색상 지정 (item.SubItems[3]이 우선순위 열)
            if (priority == "높음")
            {
                item.SubItems[3].ForeColor = Color.Red;
            }
            else if (priority == "중간")
            {
                item.SubItems[3].ForeColor = Color.Yellow;
            }
            else if (priority == "낮음")
            {
                item.SubItems[3].ForeColor = Color.Green;
            }
            change_color();
        }

        private void LoadItems()
        {
          
            if (string.IsNullOrEmpty(login_id))
            {
                listView1.Items.Clear();
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    string sql = "select id_check_ToDo, todo, period, priority, status, dateTime from `1101`.check_ToDo where user_id = @user_id";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", comboBox1.SelectedItem);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            listView1.Items.Clear();
                            while (reader.Read())
                            {
                                object db_id = reader["id_check_ToDo"];
                                string todo = Convert.ToString(reader["todo"]);
                                string dueDate = Convert.ToString(reader["period"]);
                                string date = Convert.ToDateTime(reader["dateTime"]).ToString("yyyy-MM-dd");

                                string priorityStr = "중간";
                                int p = Convert.ToInt32(reader["priority"]);
                                if (p == 1) priorityStr = "높음";
                                else if (p == 3) priorityStr = "낮음";

                                bool isChecked = Convert.ToString(reader["status"]) == "완료";

                                AddToListView(todo, dueDate, priorityStr, date, db_id, isChecked);
                            }
                        }
                    }
                }
                updateCheck();
                change_color();
            }
            catch (Exception e)
            {
                MessageBox.Show("데이터를 가져오는 중 오류가 발생했습니다:\n" + e, "오류");
            }
            finally
            {
                isLoaded = false;
            }

            foreach (ColumnHeader col in listView1.Columns)
            {
                col.Width = -2;
            }
        }

        private void OpenOrActivateForm2(Size? customSize = null)
        {
            if (isLogin == 1 || string.IsNullOrEmpty(login_id))
            {
                MessageBox.Show("로그인이 필요한 service입니다.");
                return;
            }
            f2 = Application.OpenForms["Form2"] as Form2;

            if (f2 == null || f2.IsDisposed)
            {
                f2 = new Form2(this, login_id);
                f2.StartPosition = FormStartPosition.Manual;
                f2.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                if (customSize.HasValue) f2.Size = customSize.Value;

                f2.FormClosed += (s, args) => { f2 = null; };
                f2.Show();
            }
            else
            {
                f2.StartPosition = FormStartPosition.Manual;
                f2.Location = new Point(this.Location.X + this.Width, this.Location.Y);

                if (customSize.HasValue) f2.Size = customSize.Value;

                f2.Activate();
            }
        }

        private void edit_dialog_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != 0)
                return;

            OpenOrActivateForm2(new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.20)));

            if (f2 != null)
            {
                f2.SetMainPenel = true;
                f2.SetPenel = false;
            }
        }

        private void search_button_Click(object sender, EventArgs e)
        {
            string s = textBox_search.Text.Trim();
            if (string.IsNullOrWhiteSpace(s))
            {
                MessageBox.Show("검색어를 입력해주세요.");
                return;
            }
            bool find = false;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.SubItems[1].Text.Contains(s))
                {
                    item.BackColor = Color.FromArgb(189, 252, 201);
                    item.EnsureVisible();
                    find = true;
                }
            }
            if (!find)
            {
                MessageBox.Show($"{s} 가 포함된 항목이 없습니다.");
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                string secondColumn = item.SubItems[1].Text;
                string thirdColumn = item.SubItems[2].Text;
                string forthColumn = item.SubItems[3].Text;
                if (f2 != null)
                {
                    f2.SetToDo = secondColumn;
                    f2.SetDate = (DateTime.Parse(thirdColumn) > DateTime.Today) ? thirdColumn : (DateTime.Today).ToString();
                    f2.SetSelect = forthColumn;
                    f2.SetItem = item;
                }
            }
        }

        public void deleteItems()
        {
            int c = listView1.SelectedItems.Count;
            if (c > 0)
            {
                for (int i = c - 1; i >= 0; i--)
                {
                    listView1.Items.Remove(listView1.SelectedItems[i]);
                }
            }
        }

        private int sortColumn = -1;
        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == sortColumn)
            {
                if (listView1.Sorting == SortOrder.Ascending)
                    listView1.Sorting = SortOrder.Descending;
                else
                    listView1.Sorting = SortOrder.Ascending;
            }
            else
            {
                sortColumn = e.Column;
                listView1.Sorting = SortOrder.Ascending;
            }

            listView1.ListViewItemSorter = new ListViewItemComparer(sortColumn, listView1.Sorting);
            listView1.Sort();
        }

        public void updateCheck()
        {
            int total = listView1.Items.Count;
            int count = listView1.CheckedItems.Count;

            progressText = $"완료된 할 일: {count} / {total}";

            if (total > 0)
            {
                targetProgress = (int)((double)count / total * 100);
                progressTimer.Start();
            }
            else
            {
                progressValue = 0;
            }

            panel_progress.Invalidate();
        }

        private void listView1_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (isLoaded) return;

            updateCheck();
            if (e.Item != null && e.Item.Tag != null)
            {
                object db_id = e.Item.Tag;
                string newStatus = e.Item.Checked ? "완료" : "미완료";

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connStr))
                    {
                        conn.Open();
                        string sql = "update `1101`.check_ToDo set status = @status where id_check_ToDo = @id";

                        using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@status", newStatus);
                            cmd.Parameters.AddWithValue("@id", db_id);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("체크 상태 변경 중 DB 오류 발생: " + ex.Message, "오류");
                }
            }
        }

        private void textBox_search_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_search.Text))
            {
                foreach (ListViewItem item in listView1.Items)
                {
                    item.BackColor = Color.White;
                }
                change_color();
            }
        }

        private void share_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != 0)
                return;

            OpenOrActivateForm2(new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.25)));

            if (f2 != null)
            {
                f2.SetMainPenel = true;
                f2.SetPenel = true;
            }
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            if (isLogin == 0)
            {
                DialogResult result = MessageBox.Show(
                    "로그아웃을 하시겠습니까?",
                    "경고",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Warning
                );
                if (result == DialogResult.OK)
                {
                    MessageBox.Show("로그아웃 되었습니다.");
                    login_button.Text = "로그인/회원가입";
                    label2.Text = "체크리스트";
                    listView1.Items.Clear();
                    comboBox1.Items.Clear();
                    comboBox1.Text = "";
                    isLogin = 1;
                    if (f2 != null && !f2.IsDisposed)
                        f2.DeletePicture = true;
                    progressValue = 0;
                    targetProgress = 0;
                    progressText = "완료된 할 일: 0 / 0";
                    if (progressTimer.Enabled)
                    {
                        progressTimer.Stop();
                    }
                    panel_progress.Invalidate();
                }
                else if (result == DialogResult.Cancel)
                {
                    this.Close();
                }
                return;
            }
            Form existingForm = Application.OpenForms["Form3"];

            if (existingForm == null)
            {
                Form3 f3 = new Form3(this);
                f3.StartPosition = FormStartPosition.Manual;
                f3.Size = new Size(480, 250);
                //f3.Size = new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.2));
                f3.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                f3.Show();
            }
            else
            {
                existingForm.StartPosition = FormStartPosition.Manual;
                existingForm.Size = new Size(480, 250);
                existingForm.Location = new Point(this.Location.X + this.Width, this.Location.Y);
                existingForm.Activate();
            }
        }

        private void change_color()
        {
            foreach (ListViewItem item in listView1.Items)
            {
                item.UseItemStyleForSubItems = true;

                string targetPeriodStr = "";
                foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                {
                    if (DateTime.TryParse(subItem.Text.Trim(), out _))
                    {
                        // 우선순위 열 등과 겹치지 않게 하이픈(-)이 포함된 날짜 형식을 우선 선택
                        if (subItem.Text.Contains("-"))
                        {
                            targetPeriodStr = subItem.Text.Trim();
                            break;
                        }
                    }
                }

                
                if (DateTime.TryParse(targetPeriodStr, out DateTime period))
                {
                    DateTime today = DateTime.Today;
                    TimeSpan t = period.Date - today;
                    int remain = t.Days;

                    if (remain < 0)
                    {
                        item.BackColor = Color.DimGray; 
                    }
                    else if (remain == 0)
                    {
                        item.BackColor = Color.Red; 
                    }
                    else if (remain <= 3)
                    {
                        item.BackColor = Color.Tomato;
                    }
                    else if (remain <= 7)
                    {
                        item.BackColor = Color.Orange;
                    }
                    else if (remain <= 14)
                    {
                        item.BackColor = Color.Yellow;
                    }
                    else
                    {
                        item.BackColor = Color.White;
                    }

                    if (item.BackColor == Color.Red || item.BackColor == Color.DimGray || item.BackColor == Color.Tomato || item.BackColor == Color.Orange)
                    {
                        foreach (ListViewItem.ListViewSubItem sub in item.SubItems)
                        {
                            sub.ForeColor = Color.White;
                        }
                    }
                    else
                    {
                        string priority = "";
                        foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                        {
                            if (subItem.Text == "높음" || subItem.Text == "중간" || subItem.Text == "낮음")
                            {
                                priority = subItem.Text;
                                subItem.ForeColor = (priority == "높음") ? Color.Red : (priority == "중간") ? Color.Yellow : Color.Green;
                                break;
                            }
                        }
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (f2 != null && !f2.IsDisposed)
            {
                f2.Close();
                f2 = null;
            }

            if (comboBox1.SelectedIndex != 0)
            {
                edit_dialog.BackColor = Color.Gray;
                share.BackColor = Color.Gray;
            }
            else
            {
                edit_dialog.BackColor = Color.White;
                share.BackColor = Color.White;
            }
            int approve = -1;
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    string sql = "SELECT approve FROM `1101`.check_share WHERE user_id = @select_item AND shared_id = @login_id AND requester_id<>@login_id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@select_item", comboBox1.SelectedItem);
                        cmd.Parameters.AddWithValue("@login_id", login_id);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                object myObj = reader["approve"];
                                approve = Convert.ToInt32(Convert.ToDouble(myObj));
                                if (approve == 1)
                                {

                                    DialogResult result = MessageBox.Show(
                                        $"{comboBox1.SelectedItem}님의 공유 요청을 승인하시겠습니까?",
                                        "공유 승인 요청",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Question
                                    );

                                    if (result == DialogResult.Yes)
                                    {
                                        approve = 0;
                                    }
                                    else if (result == DialogResult.No)
                                    {
                                        MessageBox.Show("요청을 거절했습니다.", "알림");
                                    }
                                    reader.Close();

                            
                                }
                                if (approve == 0)
                                {
                                    string updateSql = @"
                                            UPDATE `1101`.check_share 
                                            SET approve = 0 
                                            WHERE (user_id = @login_id AND shared_id = @select_item)
                                               OR (user_id = @select_item AND shared_id = @login_id)";
                                    using (MySqlCommand updateCmd = new MySqlCommand(updateSql, conn))
                                    {
                                        updateCmd.Parameters.AddWithValue("@select_item", comboBox1.SelectedItem);
                                        updateCmd.Parameters.AddWithValue("@login_id", login_id);

                                        int rows = updateCmd.ExecuteNonQuery();
                                        if (rows > 0)
                                        {
                                            MessageBox.Show("성공적으로 승인되었습니다.", "알림");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("체크 상태 변경 중 DB 오류 발생: " + ex.Message, "오류");
            }
            if (approve == 0 || comboBox1.SelectedItem == login_id) {
                MessageBox.Show("불러오는데 성공하였습니다.", "알림");
                string id = comboBox1.SelectedItem.ToString();
                label2.Text = id + "님의 체크리스트";
                LoadItems();
            }
            else {
                MessageBox.Show("불러오는데 실패하였습니다.", "알림");
                listView1.Items.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (isLogin == 1)
                return;

            OpenOrActivateForm2(new Size((int)(screenWidth * 0.35), (int)(screenHeight * 0.6)));
            f2.SetMainPenel = false;
            f2.SetPenel = false;
            f2.SetPenel2 = true;

            int[] data = new int[2];
            string[] labels = { "내 완료율", "전체 평균 완료율" };

            string query = @"
                SELECT 
                    IFNULL(ROUND(AVG(CASE WHEN t.status = '완료' THEN 1.0 ELSE 0.0 END) * 100, 1), 0.0) AS my_rate,
                    IFNULL(ROUND(MAX(total.avg_rate) * 100, 1), 0.0) AS total_avg_rate
                FROM (SELECT @user_id AS user_id) dummy
                LEFT JOIN check_ToDo t ON t.user_id = dummy.user_id
                CROSS JOIN (
                    SELECT AVG(CASE WHEN status = '완료' THEN 1.0 ELSE 0.0 END) AS avg_rate
                    FROM check_ToDo
                ) total";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connStr))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@user_id", comboBox1.SelectedItem);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                object myRateObj = reader["my_rate"];
                                object totalRateObj = reader["total_avg_rate"];

                                data[0] = (myRateObj != DBNull.Value) ? Convert.ToInt32(Convert.ToDouble(myRateObj)) : 0;
                                data[1] = (totalRateObj != DBNull.Value) ? Convert.ToInt32(Convert.ToDouble(totalRateObj)) : 0;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"DB 연결 중 오류 발생: {ex.Message}");
                return;
            }

            DrawMiniChart(data, labels, 100);
        }

        private void DrawMiniChart(int[] data, string[] labels, int maxValue)
        {
            // 현재 pictureBox1의 실제 크기
            int pBoxWidth = f2.pictureBox1.Width;
            int pBoxHeight = f2.pictureBox1.Height;

            // 예외 방지: 크기가 너무 작으면 그리지 않음
            if (pBoxWidth <= 0 || pBoxHeight <= 0) return;

            Bitmap bmp = new Bitmap(pBoxWidth, pBoxHeight);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.FromArgb(245, 245, 245));

                // 여백을 전체 높이/너비의 비율로 설정하여 해상도 대응
                int marginX = (int)(pBoxWidth * 0.12); 
                int marginY = (int)(pBoxHeight * 0.15);

                int chartWidth = pBoxWidth - (marginX * 2);
                int chartHeight = pBoxHeight - (marginY * 2);

                // 막대 너비와 글꼴 크기도 전체 크기에 비례하도록 설정
                int barWidth = chartWidth / 4;
                float fontSize = Math.Max(9, pBoxHeight * 0.04f);

                using (Font textFont = new Font("맑은 고딕", fontSize, FontStyle.Regular))
                using (Font valueFont = new Font("맑은 고딕", fontSize + 1, FontStyle.Bold))
                {
                    Brush[] barBrushes = { Brushes.Blue, Brushes.DarkGray };

                    for (int i = 0; i < data.Length; i++)
                    {
                        // 각 막대의 중심 X 좌표 계산
                        int x = marginX + (i * (chartWidth / 2)) + (chartWidth / 4) - (barWidth / 2);

                        // 데이터 비율 계산
                        int barHeight = (int)((double)data[i] / maxValue * chartHeight);
                        int y = pBoxHeight - marginY - barHeight;

                        // 막대 그리기
                        g.FillRectangle(barBrushes[i], x, y, barWidth, barHeight);
                        g.DrawRectangle(Pens.Black, x, y, barWidth, barHeight);

                        StringFormat sf = new StringFormat();
                        sf.Alignment = StringAlignment.Center;

                        // 하단 레이블
                        g.DrawString(labels[i], textFont, Brushes.Black, x + (barWidth / 2), pBoxHeight - marginY + (marginY * 0.2f), sf);

                        // 상단 퍼센트
                        g.DrawString($"{data[i]}%", valueFont, Brushes.Black, x + (barWidth / 2), y - (marginY * 0.9f), sf);
                    }
                }
                g.DrawLine(Pens.Black, marginX, pBoxHeight - marginY, pBoxWidth - marginX, pBoxHeight - marginY);
            }

            f2.pictureBox1.Image = bmp;
        }

        private void listView1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (isLoaded) return;
            if (comboBox1.SelectedIndex != 0)
            {
                if (listView1.FocusedItem != null)
                {
                    e.NewValue = e.CurrentValue;
                }
            }
        }

        private void panel_progress_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            int width = panel_progress.Width;
            int height = panel_progress.Height;

            g.FillRectangle(Brushes.LightGray, 0, 0, width, height);

            int progressWidth = (int)((progressValue / 100.0) * width);

            g.FillRectangle(Brushes.LimeGreen, 0, 0, progressWidth, height);
            g.DrawRectangle(Pens.Gray, 0, 0, width - 1, height - 1);

            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;

            using (Font progressFont = new Font("맑은 고딕", 10, FontStyle.Bold))
            {
                g.DrawString(progressText, progressFont, Brushes.Black, new RectangleF(0, 0, width, height), sf);
            }
        }

        private void ProgressTimer_Tick(object sender, EventArgs e)
        {
            if (progressValue < targetProgress)
            {
                progressValue++;
            }
            else if (progressValue > targetProgress)
            {
                progressValue--;
            }
            else
            {
                progressTimer.Stop();
            }

            panel_progress.Invalidate();
        }
    }
}

public class ListViewItemComparer : IComparer
{
    private int col;
    private SortOrder order;

    public ListViewItemComparer(int column, SortOrder order)
    {
        col = column;
        this.order = order;
    }

    public int Compare(object x, object y)
    {
        string textX = ((ListViewItem)x).SubItems[col].Text;
        string textY = ((ListViewItem)y).SubItems[col].Text;

        int result;

        if (col == 3)
        {
            string[] order_list = { "낮음", "중간", "높음" };
            int indexX = Array.IndexOf(order_list, textX);
            int indexY = Array.IndexOf(order_list, textY);
            result = indexX.CompareTo(indexY);
        }
        else
        {
            result = String.Compare(textX, textY);
        }

        return order == SortOrder.Ascending ? result : -result;
    }
}